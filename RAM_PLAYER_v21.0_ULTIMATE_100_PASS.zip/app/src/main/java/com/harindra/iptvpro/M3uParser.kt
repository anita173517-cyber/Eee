package com.harindra.iptvpro

import org.json.JSONObject
import java.io.BufferedReader
import java.io.Reader
import java.io.StringReader
import java.net.URLDecoder
import java.util.Locale

/**
 * RAM PLAYER v21.0 EXTREME MASTER EDITION — Universal High-Throughput M3U / M3U8 Engine.
 *
 * CRITICAL GUARANTEES:
 * - Every entry parsed from an M3U or M3U8 playlist is assigned [ContentSourceType.M3U_LIVE].
 * - Preserves actual provider `group-title` / `#EXTGRP` categories verbatim for Live TV browsing.
 * - Supports `#EXTINF`, `#EXTGRP`, `group-title`, `tvg-id`, `tvg-name`, `tvg-logo`, `tvg-chno`,
 *   `#EXTVLCOPT` (User-Agent, Referer, Origin, Cookie, Authorization), `#KODIPROP`
 *   (`stream_headers`, `manifest_headers`, direct HTTP props), pipe-separated HTTP headers,
 *   and relative URL resolution when `baseUrl` is provided.
 * - Word-boundary attribute scanning so `group=` never false-matches `group-title=`.
 * - Zero-allocation 64-bit FNV-1a URL deduplication and automatic backupUrl pairing.
 */
object M3uParser {
    private const val DEFAULT_MAX_CHANNELS = 60_000
    private const val FIRST_BATCH_SIZE = 20

    data class M3uParseStats(
        val channels: List<Channel>,
        val totalEntriesSeen: Int,
        val duplicateUrlsSkipped: Int,
        val mergedBackupCount: Int,
        val invalidEntriesSkipped: Int,
        val categoryCounts: Map<String, Int>,
        val detectedEpgUrl: String = ""
    )

    private fun extractAttributeFast(line: String, attrName: String): String {
        val searchStart = if (line.length > 8 && line.startsWith("#EXTINF:", ignoreCase = true)) 8 else 0
        var fromIdx = searchStart
        val len = line.length
        while (fromIdx < len) {
            val keyIdx = line.indexOf(attrName, startIndex = fromIdx, ignoreCase = true)
            if (keyIdx < 0) return ""
            // Ensure word boundary before attribute name (prevents `group` matching inside `group-title`)
            val prevOk = keyIdx == searchStart || line[keyIdx - 1].isWhitespace() || line[keyIdx - 1] == ',' || line[keyIdx - 1] == ':'
            var i = keyIdx + attrName.length
            while (i < len && line[i].isWhitespace()) i++
            if (prevOk && i < len && line[i] == '=') {
                i++
                while (i < len && line[i].isWhitespace()) i++
                if (i >= len) return ""
                val firstChar = line[i]
                if (firstChar == '"' || firstChar == '\'') {
                    val start = i + 1
                    val end = line.indexOf(firstChar, startIndex = start)
                    return if (end > start) line.substring(start, end).trim() else ""
                }
                var end = i
                while (end < len && !line[end].isWhitespace() && line[end] != ',') {
                    end++
                }
                return if (end > i) line.substring(i, end).trim() else ""
            }
            fromIdx = keyIdx + attrName.length
        }
        return ""
    }

    private fun inferLiveTvCategoryWhenMissing(name: String): String {
        val nameLower = name.lowercase(Locale.ROOT)
        return when {
            nameLower.contains("sport") || nameLower.contains("cricket") || nameLower.contains("football") -> "Sports"
            nameLower.contains("news") || nameLower.contains("samachar") || nameLower.contains("aaj tak") -> "News"
            nameLower.contains("movie") || nameLower.contains("cinema") || nameLower.contains("film") -> "Movies"
            nameLower.contains("music") || nameLower.contains("hits") || nameLower.contains("beats") -> "Music"
            nameLower.contains("kids") || nameLower.contains("cartoon") || nameLower.contains("nick") || nameLower.contains("pogo") -> "Kids"
            else -> "Live TV"
        }
    }

    fun fnv1a64(str: String): Long {
        var hash = -0x340d631b7bdddcdbL
        for (i in 0 until str.length) {
            hash = hash xor str[i].code.toLong()
            hash *= 0x100000001b3L
        }
        return hash
    }

    fun fnv1a64NormalizedPair(group: String, name: String): Long {
        var hash = -0x340d631b7bdddcdbL
        var gStart = 0
        var gEnd = group.length - 1
        while (gStart <= gEnd && group[gStart].isWhitespace()) gStart++
        while (gEnd >= gStart && group[gEnd].isWhitespace()) gEnd--
        for (i in gStart..gEnd) {
            hash = hash xor group[i].lowercaseChar().code.toLong()
            hash *= 0x100000001b3L
        }
        hash = hash xor '|'.code.toLong()
        hash *= 0x100000001b3L
        var nStart = 0
        var nEnd = name.length - 1
        while (nStart <= nEnd && name[nStart].isWhitespace()) nStart++
        while (nEnd >= nStart && name[nEnd].isWhitespace()) nEnd--
        for (i in nStart..nEnd) {
            hash = hash xor name[i].lowercaseChar().code.toLong()
            hash *= 0x100000001b3L
        }
        return hash
    }

    private fun isAbsoluteStreamScheme(line: String): Boolean {
        return line.startsWith("http://", ignoreCase = true) ||
            line.startsWith("https://", ignoreCase = true) ||
            line.startsWith("rtsp://", ignoreCase = true) ||
            line.startsWith("rtmp://", ignoreCase = true) ||
            line.startsWith("udp://", ignoreCase = true) ||
            line.startsWith("rtp://", ignoreCase = true) ||
            line.startsWith("mms://", ignoreCase = true) ||
            line.startsWith("mmsh://", ignoreCase = true)
    }

    private fun isUnsupportedScheme(line: String): Boolean {
        val schemeIdx = line.indexOf("://")
        return schemeIdx in 1..12 && !isAbsoluteStreamScheme(line)
    }

    private fun parseHeaderPairsInto(rawHeaders: String, target: MutableMap<String, String>) {
        for (pair in rawHeaders.split('&')) {
            val eq = pair.indexOf('=')
            if (eq > 0) {
                val key = pair.substring(0, eq).trim()
                val decodedVal = runCatching {
                    URLDecoder.decode(pair.substring(eq + 1).trim(), "UTF-8")
                }.getOrElse { pair.substring(eq + 1).trim() }
                if (key.isNotEmpty() && decodedVal.isNotEmpty()) {
                    target[key] = decodedVal
                }
            }
        }
    }

    fun parse(
        m3uContent: String,
        maxChannels: Int = DEFAULT_MAX_CHANNELS,
        shouldCancel: () -> Boolean = { false },
        onFirstBatch: ((List<Channel>) -> Unit)? = null,
        baseUrl: String? = null
    ): List<Channel> {
        return parseWithStats(
            reader = StringReader(m3uContent.removePrefix("\uFEFF")),
            maxChannels = maxChannels,
            shouldCancel = shouldCancel,
            onFirstBatch = onFirstBatch,
            baseUrl = baseUrl
        ).channels
    }

    fun parse(
        reader: Reader,
        maxChannels: Int = DEFAULT_MAX_CHANNELS,
        shouldCancel: () -> Boolean = { false },
        onFirstBatch: ((List<Channel>) -> Unit)? = null,
        baseUrl: String? = null
    ): List<Channel> {
        return parseWithStats(
            reader = reader,
            maxChannels = maxChannels,
            shouldCancel = shouldCancel,
            onFirstBatch = onFirstBatch,
            baseUrl = baseUrl
        ).channels
    }

    fun parseWithStats(
        reader: Reader,
        maxChannels: Int = DEFAULT_MAX_CHANNELS,
        shouldCancel: () -> Boolean = { false },
        onFirstBatch: ((List<Channel>) -> Unit)? = null,
        baseUrl: String? = null
    ): M3uParseStats {
        val channels = ArrayList<Channel>(4096)
        val categoryPool = HashMap<String, String>(128)
        val categoryCounts = LinkedHashMap<String, Int>(64)
        val seenUrlHashes = HashSet<Long>(4096)
        val primaryIndexByNormHash = HashMap<Long, Int>(4096)
        val pendingHeaders = LinkedHashMap<String, String>(4)

        var pendingName = ""
        var pendingGroup = ""
        var pendingLogo = ""
        var pendingId = ""
        var pendingCustomChNo = -1
        var pendingLicenseType = ""
        var pendingLicenseKey = ""
        var pendingManifestType = ""
        var hasPendingExtInf = false
        var number = 1
        var lineCounter = 0
        var firstBatchEmitted = false

        var totalEntriesSeen = 0
        var duplicateUrlsSkipped = 0
        var mergedBackupCount = 0
        var invalidEntriesSkipped = 0
        var detectedEpgUrl = ""
        var globalPlaylistUserAgent = ""

        val normalizedBaseUrl = baseUrl?.trim()?.takeIf {
            it.startsWith("http://", ignoreCase = true) || it.startsWith("https://", ignoreCase = true)
        }

        val buffered = if (reader is BufferedReader) reader else BufferedReader(reader, 65536)
        var rawLine: String? = buffered.readLine()
        while (rawLine != null) {
            lineCounter++
            if (lineCounter % 1500 == 0 && shouldCancel()) {
                break
            }
            val line = rawLine.trim().let { if (lineCounter == 1) it.removePrefix("\uFEFF") else it }
            if (line.isNotEmpty()) {
                when {
                    line.startsWith("#EXTM3U", ignoreCase = true) -> {
                        if (detectedEpgUrl.isEmpty()) {
                            detectedEpgUrl = extractAttributeFast(line, "url-tvg")
                                .ifBlank { extractAttributeFast(line, "x-tvg-url") }
                                .ifBlank { extractAttributeFast(line, "tvg-url") }
                                .substringBefore(',')
                                .trim()
                        }
                        if (globalPlaylistUserAgent.isEmpty()) {
                            globalPlaylistUserAgent = extractAttributeFast(line, "user-agent")
                                .ifBlank { extractAttributeFast(line, "http-user-agent") }
                        }
                    }
                    line.startsWith("#EXTINF:", ignoreCase = true) -> {
                        hasPendingExtInf = true
                        val comma = line.lastIndexOf(',')
                        val displayTitle = if (comma >= 0 && comma < line.lastIndex) {
                            line.substring(comma + 1).trim()
                        } else {
                            ""
                        }
                        val tvgName = extractAttributeFast(line, "tvg-name")
                        pendingName = displayTitle.ifBlank { tvgName }.ifBlank { "Channel $number" }

                        val rawGroup = extractAttributeFast(line, "group-title")
                            .ifBlank { extractAttributeFast(line, "group") }
                        pendingGroup = if (rawGroup.isNotBlank()) {
                            categoryPool.getOrPut(rawGroup) { rawGroup }
                        } else {
                            ""
                        }
                        pendingLogo = extractAttributeFast(line, "tvg-logo")
                            .ifBlank { extractAttributeFast(line, "logo") }
                        pendingId = extractAttributeFast(line, "tvg-id")
                            .ifBlank { extractAttributeFast(line, "channel-id") }
                        pendingCustomChNo = extractAttributeFast(line, "tvg-chno")
                            .ifBlank { extractAttributeFast(line, "ch-number") }
                            .toIntOrNull() ?: -1

                        val inlineUa = extractAttributeFast(line, "http-user-agent")
                            .ifBlank { extractAttributeFast(line, "user-agent") }
                        if (inlineUa.isNotEmpty()) pendingHeaders["User-Agent"] = inlineUa
                        val inlineRef = extractAttributeFast(line, "http-referrer")
                            .ifEmpty { extractAttributeFast(line, "http-referer") }
                            .ifEmpty { extractAttributeFast(line, "referer") }
                        if (inlineRef.isNotEmpty()) pendingHeaders["Referer"] = inlineRef
                        val inlineOrigin = extractAttributeFast(line, "http-origin")
                            .ifEmpty { extractAttributeFast(line, "origin") }
                        if (inlineOrigin.isNotEmpty()) pendingHeaders["Origin"] = inlineOrigin
                        val inlineCookie = extractAttributeFast(line, "http-cookie")
                            .ifEmpty { extractAttributeFast(line, "cookie") }
                        if (inlineCookie.isNotEmpty()) pendingHeaders["Cookie"] = inlineCookie
                    }
                    line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                        val rawGroup = line.substringAfter(':').trim()
                        if (rawGroup.isNotBlank()) {
                            pendingGroup = categoryPool.getOrPut(rawGroup) { rawGroup }
                        }
                    }
                    line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                        val opt = line.substringAfter(':').trim()
                        when {
                            opt.startsWith("http-user-agent=", ignoreCase = true) -> {
                                val ua = opt.substringAfter('=').trim()
                                if (ua.isNotEmpty()) pendingHeaders["User-Agent"] = ua
                            }
                            opt.startsWith("http-referrer=", ignoreCase = true) ||
                                opt.startsWith("http-referer=", ignoreCase = true) -> {
                                val ref = opt.substringAfter('=').trim()
                                if (ref.isNotEmpty()) pendingHeaders["Referer"] = ref
                            }
                            opt.startsWith("http-origin=", ignoreCase = true) -> {
                                val origin = opt.substringAfter('=').trim()
                                if (origin.isNotEmpty()) pendingHeaders["Origin"] = origin
                            }
                            opt.startsWith("http-cookie=", ignoreCase = true) -> {
                                val cookie = opt.substringAfter('=').trim()
                                if (cookie.isNotEmpty()) pendingHeaders["Cookie"] = cookie
                            }
                            opt.startsWith("http-authorization=", ignoreCase = true) -> {
                                val auth = opt.substringAfter('=').trim()
                                if (auth.isNotEmpty()) pendingHeaders["Authorization"] = auth
                            }
                        }
                    }
                    line.startsWith("#EXTHTTP:", ignoreCase = true) -> {
                        val jsonStr = line.substringAfter(':').trim()
                        if (jsonStr.startsWith('{') && jsonStr.endsWith('}')) {
                            runCatching {
                                val obj = JSONObject(jsonStr)
                                val keys = obj.keys()
                                while (keys.hasNext()) {
                                    val k = keys.next().trim()
                                    val v = obj.optString(k, "").trim()
                                    if (k.isNotEmpty() && v.isNotEmpty()) {
                                        pendingHeaders[k] = v
                                    }
                                }
                            }
                        }
                    }
                    line.startsWith("#KODIPROP:", ignoreCase = true) -> {
                        val prop = line.substringAfter(':').trim()
                        when {
                            prop.startsWith("inputstream.adaptive.stream_headers=", ignoreCase = true) ||
                                prop.startsWith("inputstream.adaptive.manifest_headers=", ignoreCase = true) -> {
                                parseHeaderPairsInto(prop.substringAfter('=').trim(), pendingHeaders)
                            }
                            prop.startsWith("inputstream.adaptive.license_type=", ignoreCase = true) -> {
                                val lt = prop.substringAfter('=').trim()
                                if (lt.isNotEmpty()) pendingLicenseType = lt
                            }
                            prop.startsWith("inputstream.adaptive.license_key=", ignoreCase = true) ||
                                prop.startsWith("inputstream.adaptive.license_data=", ignoreCase = true) -> {
                                val lk = prop.substringAfter('=').trim()
                                if (lk.isNotEmpty()) pendingLicenseKey = lk
                            }
                            prop.startsWith("inputstream.adaptive.drm_legacy=", ignoreCase = true) -> {
                                val legacy = prop.substringAfter('=').trim()
                                val bar = legacy.indexOf('|')
                                if (bar > 0 && bar < legacy.lastIndex) {
                                    pendingLicenseType = legacy.substring(0, bar).trim()
                                    pendingLicenseKey = legacy.substring(bar + 1).trim()
                                }
                            }
                            prop.startsWith("inputstream.adaptive.manifest_type=", ignoreCase = true) -> {
                                val mt = prop.substringAfter('=').trim()
                                if (mt.isNotEmpty()) pendingManifestType = mt
                            }
                            prop.startsWith("http-user-agent=", ignoreCase = true) -> {
                                val ua = prop.substringAfter('=').trim()
                                if (ua.isNotEmpty()) pendingHeaders["User-Agent"] = ua
                            }
                            prop.startsWith("http-referer=", ignoreCase = true) ||
                                prop.startsWith("http-referrer=", ignoreCase = true) -> {
                                val ref = prop.substringAfter('=').trim()
                                if (ref.isNotEmpty()) pendingHeaders["Referer"] = ref
                            }
                            prop.startsWith("http-cookie=", ignoreCase = true) -> {
                                val ck = prop.substringAfter('=').trim()
                                if (ck.isNotEmpty()) pendingHeaders["Cookie"] = ck
                            }
                        }
                    }
                    !line.startsWith("#") -> {
                        val candidateUrlLine: String? = when {
                            isAbsoluteStreamScheme(line) -> line
                            isUnsupportedScheme(line) -> null
                            normalizedBaseUrl != null && hasPendingExtInf && !line.contains(' ') -> {
                                val pipeIdx = line.indexOf('|')
                                val rawPath = if (pipeIdx > 0) line.substring(0, pipeIdx).trim() else line
                                val pipeSuffix = if (pipeIdx > 0) line.substring(pipeIdx) else ""
                                val resolved = StreamPreFetcher.resolveRelativeUrl(normalizedBaseUrl, rawPath)
                                if (resolved.isNotBlank() && isAbsoluteStreamScheme(resolved)) {
                                    resolved + pipeSuffix
                                } else {
                                    null
                                }
                            }
                            else -> null
                        }

                        if (candidateUrlLine == null) {
                            invalidEntriesSkipped++
                        } else {
                            totalEntriesSeen++
                            if (globalPlaylistUserAgent.isNotEmpty() && pendingHeaders.keys.none { it.equals("User-Agent", ignoreCase = true) }) {
                                pendingHeaders["User-Agent"] = globalPlaylistUserAgent
                            }
                            val cleanUrl = if (candidateUrlLine.indexOf('|') > 0 || pendingHeaders.isNotEmpty()) {
                                NetworkClient.extractCleanUrlAndRegisterHeaders(candidateUrlLine, pendingHeaders)
                            } else {
                                candidateUrlLine
                            }
                            if (cleanUrl.isNotEmpty()) {
                                if (pendingLicenseType.isNotEmpty() || pendingLicenseKey.isNotEmpty() || pendingManifestType.isNotEmpty()) {
                                    NetworkClient.registerStreamDrmConfig(
                                        cleanUrl,
                                        NetworkClient.StreamDrmConfig(
                                            licenseType = pendingLicenseType,
                                            licenseKey = pendingLicenseKey,
                                            manifestType = pendingManifestType
                                        )
                                    )
                                }
                                if (!seenUrlHashes.add(fnv1a64(cleanUrl))) {
                                    duplicateUrlsSkipped++
                                } else {
                                    val resolvedName = pendingName.ifBlank { "Channel $number" }
                                    val rawResolvedGroup = if (pendingGroup.isNotBlank()) {
                                        pendingGroup
                                    } else {
                                        inferLiveTvCategoryWhenMissing(resolvedName)
                                    }
                                    val resolvedGroup = categoryPool.getOrPut(rawResolvedGroup) { rawResolvedGroup }
                                    val normHash = fnv1a64NormalizedPair(resolvedGroup, resolvedName)
                                    val existingIdx = primaryIndexByNormHash[normHash]
                                    if (existingIdx != null && existingIdx in channels.indices && channels[existingIdx].backupUrl.isEmpty()) {
                                        val primary = channels[existingIdx]
                                        channels[existingIdx] = primary.copy(backupUrl = cleanUrl)
                                        mergedBackupCount++
                                    } else {
                                        val assignedNumber = if (pendingCustomChNo > 0) pendingCustomChNo else number
                                        val newIdx = channels.size
                                        channels.add(
                                            Channel(
                                                id = if (pendingId.isNotEmpty()) "${pendingId}_$number" else "m3u_$number",
                                                number = assignedNumber,
                                                name = resolvedName,
                                                category = resolvedGroup,
                                                streamUrl = cleanUrl,
                                                logoUrl = pendingLogo,
                                                epgId = pendingId,
                                                sourceType = ContentSourceType.M3U_LIVE
                                            )
                                        )
                                        categoryCounts[resolvedGroup] = (categoryCounts[resolvedGroup] ?: 0) + 1
                                        primaryIndexByNormHash.putIfAbsent(normHash, newIdx)
                                        number++
                                        if (!firstBatchEmitted && channels.size == FIRST_BATCH_SIZE && onFirstBatch != null) {
                                            firstBatchEmitted = true
                                            onFirstBatch(ArrayList(channels))
                                        }
                                        if (channels.size >= maxChannels) break
                                    }
                                }
                            } else {
                                invalidEntriesSkipped++
                            }
                        }
                        pendingName = ""
                        pendingGroup = ""
                        pendingLogo = ""
                        pendingId = ""
                        pendingCustomChNo = -1
                        hasPendingExtInf = false
                        pendingLicenseType = ""
                        pendingLicenseKey = ""
                        pendingManifestType = ""
                        pendingHeaders.clear()
                    }
                }
            }
            rawLine = buffered.readLine()
        }
        return M3uParseStats(
            channels = channels,
            totalEntriesSeen = totalEntriesSeen,
            duplicateUrlsSkipped = duplicateUrlsSkipped,
            mergedBackupCount = mergedBackupCount,
            invalidEntriesSkipped = invalidEntriesSkipped,
            categoryCounts = categoryCounts,
            detectedEpgUrl = detectedEpgUrl
        )
    }
}
